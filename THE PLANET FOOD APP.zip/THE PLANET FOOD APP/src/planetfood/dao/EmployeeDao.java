package planetfood.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import planetfood.dbutil.DBConnection;
import planetfood.pojo.Employee;

public class EmployeeDao {
    public static String getNewID()throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("Select count(*) from Employees");
        int id = 101;
        ResultSet rs = ps.executeQuery();
        if(rs.next()){
            id += rs.getInt(1);
        }
        return "E"+id;
    }
     public static boolean addEmployee(Employee e)throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("Insert into employees values (?,?,?,?,?)");
        ps.setString(1, e.getEmpId());
        ps.setString(2, e.getEmpName());
        ps.setString(3, e.getJob());
        ps.setDouble(4, e.getSal());
        ps.setString(5, e.getPresent());
        int x = ps.executeUpdate();
        return (x>0);
    }
    public static HashMap <String,Employee> getEmployeesByEmpId()throws SQLException
    {
        Statement st = DBConnection.getConnection().createStatement();
        HashMap <String,Employee> employeeList = new HashMap<>();
        ResultSet rs = st.executeQuery("Select * from employees where present='Y'");
        while(rs.next()){
            Employee e = new Employee();
            e.setEmpId(rs.getString("empid"));
            e.setEmpName(rs.getString("ename"));
            e.setJob(rs.getString("job"));
            e.setSal(rs.getDouble("sal"));
            employeeList.put(e.getEmpId(), e);
        }
        return employeeList;
    }
    public static ArrayList<Employee>getAllData()throws SQLException
    {
        Statement st = DBConnection.getConnection().createStatement();
        ResultSet rs = st.executeQuery("select * from employees where present='Y'");
        ArrayList <Employee> employeeList = new ArrayList<>();
        while(rs.next())
        {
            Employee e = new Employee();
            e.setEmpId(rs.getString("empid"));
            e.setEmpName(rs.getString("ename"));
            e.setJob(rs.getString("job"));
            e.setSal(rs.getDouble("sal"));
            employeeList.add(e);
        }
        return employeeList;
    }
    public static boolean updateEmployee(Employee e)throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("Update Employees set ename=? ,job=? ,sal=? where empid=?");
        ps.setString(1, e.getEmpName());
        ps.setString(2, e.getJob());
        ps.setDouble(3, e.getSal());
        ps.setString(4, e.getEmpId());
        int x = ps.executeUpdate();
        return (x>0);
    }
    public static boolean removeEmployee(String empId)throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("Update Employees set present = 'N' where empid=?");
        ps.setString(1, empId);
        int x = ps.executeUpdate();
        return(x>0);
    }
}
