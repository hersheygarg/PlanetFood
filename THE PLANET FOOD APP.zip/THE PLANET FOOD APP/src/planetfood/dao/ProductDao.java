package planetfood.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import planetfood.dbutil.DBConnection;
import planetfood.pojo.Product;

public class ProductDao {
    public static String getNewID()throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("Select count(*) from Products");
        int id = 101;
        ResultSet rs = ps.executeQuery();
        if(rs.next()){
            id += rs.getInt(1);
        }
        return "P"+id;
    }
    public static boolean addProduct(Product p)throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("Insert into products values (?,?,?,?,?)");
        ps.setString(1, p.getProdId());
        ps.setString(2, p.getCatId());
        ps.setString(3, p.getProdName());
        ps.setDouble(4, p.getProdPrice());
        ps.setString(5, p.getIsActive());
        int x = ps.executeUpdate();
        return (x>0);
    }
    public static HashMap <String,Product> getProductsByCategory(String catId)throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("Select * from products where cat_id=?");
        HashMap <String,Product> productList = new HashMap<>();
        ps.setString(1, catId);
        ResultSet rs = ps.executeQuery();
        while(rs.next()){
            Product p = new Product();
            p.setCatId(catId);
            p.setProdId(rs.getString("prod_id"));
            p.setProdName(rs.getString("prod_name"));
            p.setProdPrice(rs.getDouble("prod_price"));
            p.setIsActive(rs.getString("active"));
            productList.put(p.getProdId(), p);
        }
        return productList;
    }
    public static ArrayList<Product>getAllData()throws SQLException
    {
        Statement st = DBConnection.getConnection().createStatement();
        ResultSet rs = st.executeQuery("select * from products");
        ArrayList <Product> productList = new ArrayList<>();
        while(rs.next())
        {
            Product p = new Product();
            p.setCatId(rs.getString("cat_id"));
            p.setProdId(rs.getString("prod_id"));
            p.setProdName(rs.getString("prod_name"));
            p.setProdPrice(rs.getDouble("prod_price"));
            p.setIsActive(rs.getString("active"));
            productList.add(p);
        }
        return productList;
    }
    public static boolean updateProduct(Product p)throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("Update products set cat_id=? ,prod_name=? ,prod_price=? ,active=?  where prod_id=?");
        ps.setString(1, p.getCatId());
        ps.setString(2, p.getProdName());
        ps.setDouble(3, p.getProdPrice());
        ps.setString(4, p.getIsActive());
        ps.setString(5, p.getProdId());
        int x = ps.executeUpdate();
        return (x>0);
    }
    public static boolean removeProduct(String prodId)throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("Update Products set active = 'N' where prod_id=?");
        ps.setString(1, prodId);
        int x = ps.executeUpdate();
        return(x>0);
    }
    public static HashMap <String,String> getActiveProductsByCategory(String catId)throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("Select prod_name,prod_id from products where cat_id=? and active='Y'");
        ps.setString(1,catId);
        ResultSet rs = ps.executeQuery();
        HashMap <String,String> productList = new HashMap<>();
        while(rs.next()){
            String prodName = rs.getString("prod_name");
            String prodId = rs.getString("prod_id");
            productList.put(prodName,prodId);
        }
        return productList;
    }
}
