package planetfood.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import planetfood.dbutil.DBConnection;
import planetfood.pojo.Employee;
import planetfood.pojo.User;
public class UserDao {
public static String validateUser(User user)throws SQLException{
    PreparedStatement ps = DBConnection.getConnection().prepareStatement("Select username from Users where userid=? and password=? and usertype=?");
    ps.setString(1, user.getUserId());
    ps.setString(2, user.getPassword());
    ps.setString(3, user.getUserType());
    ResultSet rs = ps.executeQuery();
    String username = null;
    if(rs.next()){
        username = rs.getString(1);
    }
    return username;
}    
 public static boolean registerUser(User u)throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("Insert into users values (?,?,?,?,?)");
        ps.setString(1, u.getUserId());
        ps.setString(2, u.getUserName());
        ps.setString(3, u.getEmpId());
        ps.setString(4, u.getPassword());
        ps.setString(5, u.getUserType());
        int x = ps.executeUpdate();
        return (x>0);
    }
    public static HashMap <String,User> getUsersByUserId()throws SQLException
    {
        Statement st = DBConnection.getConnection().createStatement();
        HashMap <String,User> userList = new HashMap<>();
        ResultSet rs = st.executeQuery("Select * from users where usertype='Cashier'");
        while(rs.next()){
            User e = new User();
            e.setUserId(rs.getString("userid"));
            e.setUserName(rs.getString("username"));
            e.setEmpId(rs.getString("empid"));
            e.setPassword(rs.getString("password"));
            e.setUserType(rs.getString("usertype"));
            userList.put(e.getUserId(), e);
        }
        return userList;
    }
public static HashMap <String,String> getEmployeeByEmpId()throws SQLException
    {
        Statement st = DBConnection.getConnection().createStatement();
        HashMap <String,String> employeeList = new HashMap<>();
        ResultSet rs = st.executeQuery("Select empid,ename from employees where job = 'Cashier' ");
        while(rs.next()){
            Employee e = new Employee();
            e.setEmpId(rs.getString("empid"));
            e.setEmpName(rs.getString("ename"));
            employeeList.put(e.getEmpId(), e.getEmpName());
        }
        return employeeList;
    }
public static ArrayList <String> getUserByUserId()throws SQLException
    {
        Statement st = DBConnection.getConnection().createStatement();
        ArrayList <String> userList = new ArrayList<>();
        ResultSet rs = st.executeQuery("Select empid from users where usertype='Cashier'");
        while(rs.next()){
            User u = new User();
            u.setEmpId(rs.getString("empid"));
            userList.add(u.getEmpId());
        }
        return userList;
    }
    public static ArrayList<String> getUserIds()throws SQLException{
        ArrayList <String> userIdList = new ArrayList<>();
        Statement st = DBConnection.getConnection().createStatement();
        ResultSet rs = st.executeQuery("select userid from users");
        while(rs.next()){
            userIdList.add(rs.getString(1));
        }
        return userIdList;
    }
    public static boolean removeCashier(String userId)throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("Delete from users where userid=?");
        ps.setString(1, userId);
        int x = ps.executeUpdate();
        return(x>0);
    }
}
