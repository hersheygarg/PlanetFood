package planetfood.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import planetfood.dbutil.DBConnection;
import planetfood.pojo.Category;

public class CategoryDao {
    public static String getNewID()throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("Select count(*) from Categories");
        int id = 101;
        ResultSet rs = ps.executeQuery();
        if(rs.next()){
            id += rs.getInt(1);
        }
        return "C"+id;
    }
     public static boolean addCategory(Category e)throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("Insert into categories values (?,?)");
        ps.setString(1, e.getCatId());
        ps.setString(2, e.getCatName());
        int x = ps.executeUpdate();
        return (x>0);
    }
    public static HashMap <String,String> getAllCategoryId()throws SQLException
    {
          Statement st = DBConnection.getConnection().createStatement();
          ResultSet rs = st.executeQuery("Select cat_name,cat_id from categories");
          HashMap<String,String> categories = new HashMap<>();
          while(rs.next()){
              String catName = rs.getString(1);
              String catId = rs.getString(2);
              categories.put(catName,catId);
          }
          return categories;
    }
    public static HashMap <String,Category> getCategoryByCatId()throws SQLException
    {
        Statement st = DBConnection.getConnection().createStatement();
        HashMap <String,Category> categoryList = new HashMap<>();
        ResultSet rs = st.executeQuery("Select * from categories");
        while(rs.next()){
            Category e = new Category();
            e.setCatId(rs.getString("cat_id"));
            e.setCatName(rs.getString("cat_name"));
            
            categoryList.put(e.getCatId(), e);
        }
        return categoryList;
    }
     public static ArrayList<Category>getAllData()throws SQLException
    {
        Statement st = DBConnection.getConnection().createStatement();
        ResultSet rs = st.executeQuery("select * from categories");
        ArrayList <Category> categoryList = new ArrayList<>();
        while(rs.next())
        {
            Category c = new Category();
            c.setCatId(rs.getString("cat_id"));
            c.setCatName(rs.getString("cat_name"));
            categoryList.add(c);
        }
        return categoryList;
    }
    public static boolean updateCategory(Category e)throws SQLException
    {
        PreparedStatement ps = DBConnection.getConnection().prepareStatement("Update Categories set cat_name=? where cat_id=?");
        ps.setString(1, e.getCatName());
        ps.setString(2, e.getCatId());
        int x = ps.executeUpdate();
        return (x>0);
    }
}
